package lombok;

public class NoArgsConstructor {

}
