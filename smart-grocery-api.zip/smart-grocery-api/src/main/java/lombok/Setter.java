package lombok;

public class Setter {

}
