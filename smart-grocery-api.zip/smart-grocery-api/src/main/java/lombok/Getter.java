package lombok;

public class Getter {

}
