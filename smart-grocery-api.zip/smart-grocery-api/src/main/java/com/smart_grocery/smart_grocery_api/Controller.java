package com.smart_grocery.smart_grocery_api;


import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	@PostMapping("/test")
 public String test() {
	 return "Hello Kavya";
 }
}

