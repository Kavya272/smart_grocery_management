//package com.smart_grocery.smart_grocery_api;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.smart_grocery.smart_grocery_api.repository.GroceryRepository;
//
//@Component
//public class DataSeeder {
//
//	@Autowired
//	private GroceryRepository groceryRepository;
//	
//	
//	public void run(String . . .args)
//	
//}


//package com.smart_grocery.smart_grocery_api;
//
//import java.util.Arrays;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//import com.smart_grocery.smart_grocery_api.entities.GroceryEntity;
//import com.smart_grocery.smart_grocery_api.repository.GroceryRepository;
//
//@Component
//public class DataSeeder implements CommandLineRunner {
//    
//    @Autowired
//    private GroceryRepository groceryRepository;
//    
//    @Override
//    public void run(String... args) throws Exception {
//        // Check if the table is empty
//        if (groceryRepository.count() == 0) {
//            // Seed demo data
//            List<GroceryEntity> groceries = Arrays.asList(
//                new GroceryEntity("Rice", 50),
//                new GroceryEntity("Wheat Flour", 30),
//                new GroceryEntity("Sugar", 25),
//                new GroceryEntity("Salt", 40),
//                new GroceryEntity("Milk", 20),
//                new GroceryEntity("Eggs", 100),
//                new GroceryEntity("Cooking Oil", 15),
//                new GroceryEntity("Lentils", 35),
//                new GroceryEntity("Spices", 10),
//                new GroceryEntity("Vegetables", 80)
//            );
//            
//            groceryRepository.saveAll(groceries);
//            System.out.println("Grocery data seeded");
//        }
//    }
//}

package com.smart_grocery.smart_grocery_api;

import java.util.Arrays;
import java.util.List;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.smart_grocery.smart_grocery_api.entities.GroceryEntity;
import com.smart_grocery.smart_grocery_api.repository.GroceryRepository;

@Component
public class DataSeeder implements CommandLineRunner {

    private final GroceryRepository groceryRepository;

    // ✅ Best Practice: Use Constructor Injection
    public DataSeeder(GroceryRepository groceryRepository) {
        this.groceryRepository = groceryRepository;
    }

    @Override
    public void run(String... args) {
        if (groceryRepository.count() == 0) {  // ✅ Check if database is empty before seeding
            List<GroceryEntity> groceries = Arrays.asList(
                new GroceryEntity("Rice", 50, 40.0, 5),
                new GroceryEntity("Wheat Flour", 30, 35.0, 3),
                new GroceryEntity("Sugar", 25, 50.0, 2),
                new GroceryEntity("Salt", 40, 15.0, 1),
                new GroceryEntity("Milk", 20, 25.0, 2),
                new GroceryEntity("Eggs", 100, 5.0, 10),
                new GroceryEntity("Cooking Oil", 15, 150.0, 1),
                new GroceryEntity("Lentils", 35, 80.0, 3),
                new GroceryEntity("Spices", 10, 200.0, 1),
                new GroceryEntity("Vegetables", 80, 30.0, 5)
            );

            groceryRepository.saveAll(groceries);
            System.out.println("✅ Grocery data seeded successfully!");
        } else {
            System.out.println("⚡ Grocery data already exists, skipping seeding.");
        }
    }
}

